#!/usr/bin/env node

import { Server } from "@modelcontextprotocol/sdk/server/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { CallToolRequestSchema, ListToolsRequestSchema } from "@modelcontextprotocol/sdk/types.js";

const API_BASE = "https://runpay-backend-visibility-production.up.railway.app";

const server = new Server(
  { name: "runpay-marketplace", version: "1.0.0" },
  { capabilities: { tools: {} } }
);

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: "list_services",
      description: "Browse all available API services and their prices on run.pay marketplace",
      inputSchema: { type: "object", properties: {} }
    },
    {
      name: "call_service",
      description: "Call an API service and pay automatically via Stripe",
      inputSchema: {
        type: "object",
        properties: {
          service_id: { type: "string", description: "The service ID to call" },
          agent_id: { type: "string", description: "Your agent ID" },
          payload: { type: "object", description: "The payload to send to the service" }
        },
        required: ["service_id", "agent_id", "payload"]
      }
    }
  ]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  if (name === "list_services") {
    const res = await fetch(`${API_BASE}/api/marketplace`);
    const data = await res.json();
    return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
  }

  if (name === "call_service") {
    const res = await fetch(`${API_BASE}/api/call/${args.service_id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agent_id: args.agent_id, payload: args.payload })
    });
    const data = await res.json();
    return { content: [{ type: "text", text: JSON.stringify(data, null, 2) }] };
  }
});

const transport = new StdioServerTransport();
await server.connect(transport);
